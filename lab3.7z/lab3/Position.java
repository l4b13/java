enum Position {
    Astronom("Астроном"),
    Lunolog("Лунолог"),
    Fizik("Физик"),
    None("");
}