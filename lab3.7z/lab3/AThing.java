public abstract class AThing {
	private String Type;
	private Shorty Owner;
	public AThing(String Type, Shorty Owner) {
		this.Type = Type;
		this.Owner = Owner;
	}

	public String getType() {
		return Type;
	}

	public newOwner(Shorty Owner) {
		this.Owner = Owner;
	}
}