public interface IShorty {
	public void LayDown(Furniture f);
	public void GetUp();
	public void Give(AThing t, Shorty s);
	public void MoveTo(ALocation l);
}