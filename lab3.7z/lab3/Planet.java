enum Planet {
    Earth("Земля"),
    Moon("Луна");
}