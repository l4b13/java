public class Thing extends AThing {
	public Thing(String Type, Shorty Owner) {
		super(Type, Owner);
	}
}