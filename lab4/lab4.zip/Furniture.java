public class Furniture extends AThing {
	public Furniture(String Type, Shorty Owner) {
		super(Type, Owner);
	}
}