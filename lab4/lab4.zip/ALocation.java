public abstract class ALocation {
	private String Name;
	public ALocation(String Name) {
		this.Name = Name;
	}
	public String getName() {
		return Name;
	}
}