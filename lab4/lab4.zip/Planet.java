enum Planet {
    Earth, 
    Moon, 
    Other;
}