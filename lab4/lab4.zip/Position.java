enum Position {
    Astronom,
    Lunolog,
    Fizik,
    Doctor,
    None;
}